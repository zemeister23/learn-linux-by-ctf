# Cat

Let's begin our first challenge.
The command `cat` can display the output of files.
Type `cat flag.txt` in order to get the next flag :)


!!! note: display description of a challenge
	the command `display-challenge` will display the challenge description again


## Useful commands
* cat
* ls
* touch
